// Define vector unit width here
#define VECTOR_WIDTH 4
#define EXP_MAX 10
